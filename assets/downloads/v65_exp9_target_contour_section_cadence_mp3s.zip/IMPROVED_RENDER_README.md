# Improved render note

These legacy MP3-only artifacts were remastered for the public listening site with EQ, light room ambience, compression, and loudness normalization. The original source MIDI for these older bundles is not present in the published artifacts, so this is an audio-production cleanup rather than a full re-instrumentation. The underlying generated notes are unchanged.
