# Full combo listening renders

This archive was rebuilt for the public JazzMLProject progress site.

All website-facing MIDI-backed outputs are rendered as a jazz combo:
- Tenor Sax Solo lead
- Comping Piano
- Walking Bass
- Jazz Drum Kit
- light deterministic timing/velocity humanization
- FluidSynth + TimGM6mb.sf2 render with room ambience, EQ, compression, and loudness normalization

The generated notes are unchanged. This is a rendering/listening-quality update only, not a new model version.
