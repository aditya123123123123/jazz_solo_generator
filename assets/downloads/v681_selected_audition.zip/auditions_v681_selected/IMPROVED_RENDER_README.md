# Improved listening render

This archive was re-rendered for the public JazzMLProject progress site.

Changes applied to the MIDI render only:
- solo track uses GM Tenor Sax instead of the old generic piano/sine-like program;
- rhythm section tracks are named/voiced as comping piano, walking bass, and jazz drum kit;
- light humanized velocity/timing variation;
- FluidSynth + TimGM6mb soundfont render with compression, room echo, and loudness normalization.

The underlying generated notes/chords are unchanged; this is a production/rendering upgrade, not a new model version.
